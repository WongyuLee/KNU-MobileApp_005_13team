package com.example.a.a07_database;


import android.app.ListActivity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.widget.SimpleCursorAdapter;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.Toast;

public class UpAct extends ListActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_up);
        loadDB();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadDB();
    }

    public void loadDB() {
        //deleteDatabase("test.db")
        SQLiteDatabase db = openOrCreateDatabase(
                "test.db",
                SQLiteDatabase.CREATE_IF_NECESSARY,
                null);

        db.execSQL("CREATE TABLE IF NOT EXISTS people "
                + "(_id INTEGER PRIMARY KEY AUTOINCREMENT, id INTEGER, name TEXT, age INTEGER);");

        Cursor c = db.rawQuery("SELECT * FROM people;", null);
        startManagingCursor(c);

        ListAdapter adapt = new SimpleCursorAdapter(
                this,
                android.R.layout.simple_list_item_2,
                c,
                new String[]{"phonenumber", "name", "age"},
                new int[]{android.R.id.text1, android.R.id.text2}, 0);

        setListAdapter(adapt);

        if (db != null) {
            db.close();
        }
    }

    public void onClickButton(View v) {
        EditText txt = null;
        txt = (EditText)findViewById(R.id.editText5);
        String phonenumberb = txt.getText().toString();
        txt = (EditText)findViewById(R.id.editText6);
        String nameb = txt.getText().toString();
        txt = (EditText)findViewById(R.id.editText7);
        String ageb = txt.getText().toString();
        if(nameb.length()<21&&Integer.parseInt(ageb)<151)
        {
        String sql = "UPDATE people SET name = '"+nameb+"', age = "+ageb+" WHERE id ="+phonenumberb+";";
        //String sql = "INSERT INTO people (name, age) VALUES ('jeongkook', 22);";

        SQLiteDatabase db = openOrCreateDatabase(
                "test.db",
                SQLiteDatabase.CREATE_IF_NECESSARY,
                null );

        db.execSQL(sql);

        finish(); //Call this when your activity is done and should be closed.
        }
        else
        {
            Toast.makeText(this,"조건을 확인해주세요.",Toast.LENGTH_SHORT).show();
        }
    }



}
