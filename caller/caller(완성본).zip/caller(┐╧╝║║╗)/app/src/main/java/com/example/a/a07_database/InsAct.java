package com.example.a.a07_database;


import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class InsAct extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ins);
    }

    public void onClickButton(View v) {
        EditText txt = null;
        txt = (EditText)findViewById(R.id.editText1);
        String phonenumber = txt.getText().toString();
        txt = (EditText)findViewById(R.id.editText2);
        String name  = txt.getText().toString();
        txt = (EditText)findViewById(R.id.editText3);
        String age = txt.getText().toString();
        if(phonenumber.length()==10&&name.length()<21&&Integer.parseInt(age)<151)
        {
            String sql = "INSERT INTO people (phonenumber, name, age) VALUES ("+phonenumber+" ,'" + name + "'," +age+");";
            //String sql = "INSERT INTO people (name, age) VALUES ('jeongkook', 22);";

            SQLiteDatabase db = openOrCreateDatabase(
                    "test.db",
                    SQLiteDatabase.CREATE_IF_NECESSARY,
                    null );

            db.execSQL(sql);

            finish(); //Call this when your activity is done and should be closed.
        }
        else
        {
            Toast.makeText(this,"조건을 확인해주세요.",Toast.LENGTH_SHORT).show();
        }
    }
}
